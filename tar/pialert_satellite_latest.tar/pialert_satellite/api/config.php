<?php
$valid_tokens = array();
?>
